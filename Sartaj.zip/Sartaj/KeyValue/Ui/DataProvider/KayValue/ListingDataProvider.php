<?php
/**
 * UI dataprovider class
 *
 * Created By : Sartaj
 */
namespace Sartaj\KeyValue\Ui\DataProvider\KeyValue;

class ListingDataProvider extends \Magento\Framework\View\Element\UiComponent\DataProvider\DataProvider
{
	
}
