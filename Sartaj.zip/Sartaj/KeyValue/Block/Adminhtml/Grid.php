<?php
/**
 * Grid block class
 *
 * Created By : Sartaj
 */
namespace Sartaj\KeyValue\Block\Adminhtml;


class Grid extends \Magento\Backend\Block\Widget\Grid
{

}