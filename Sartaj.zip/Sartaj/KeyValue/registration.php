<?php
/**
 * Module registration file
 * created by: Sartaj
 */
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Sartaj_KeyValue', __DIR__);

